/**
 * Title: gpa.component.ts
 * Author: Chris Bohnet
 * Date: 11 August 2020
 * Description: gpa.component file
 */
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-invoice',
  templateUrl: './gpa.component.html',
  styleUrls: ['./gpa.component.css']
})
export class GpaComponent implements OnInit {

  @Input() invoiceTotal: number;

  constructor() { }

  ngOnInit(): void {
  }

}
