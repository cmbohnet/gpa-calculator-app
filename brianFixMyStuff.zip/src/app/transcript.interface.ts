/**
 * Title: transcript.interface.ts
 * Author: Chris Bohnet
 * Date: 11 August 2020
 * Description: transcript.interface file
 * NO LONGER USED
 */
export interface ITranscript {
  course: string;
  grade: string;
}
