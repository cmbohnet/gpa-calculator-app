/**
 * Title: services.interface.ts
 * Author: Chris Bohnet
 * Date: 11 August 2020
 * Description: services.interface file
 * NO LONGER USED
 */
export interface IService {
  description: string;
  cost: number;
}
