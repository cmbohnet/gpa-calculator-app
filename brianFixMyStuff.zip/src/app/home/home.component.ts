/**
 * Title: home.component.ts
 * Author: Chris Bohnet
 * Date: 11 August 2020
 * Description: home.component file
 */
import { Component, OnInit, NgModule } from '@angular/core';
import { IService } from '../services.interface';
//import { ITranscript } from '../transcript.interface';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_CHECKBOX_DEFAULT_OPTIONS } from '@angular/material/checkbox';



@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']


})
export class HomeComponent implements OnInit {

  //transcriptEntries: Array<ITranscript> = [];
  invoiceTotal: number = 0;;
  servicesForm: FormGroup;
  parts: 0;
  labor: 0;
  services: Array<IService> = [];
  service: IService;



  //master_checked: boolean = false;
  //master_indeterminate: boolean = false;

  checkbox_list = [];
  services_selected_list = [];

  constructor(private fb: FormBuilder) {
    this.checkbox_list = [
      {
        name: "Password Reset ($39.99)",
        disabled: false,
        checked: false,
        labelPosition: "after"
      }, {
        name: "Spyware Removal ($99.99)",
        disabled: false,
        checked: false,
        labelPosition: "after"
      }, {
        name: "RAM Upgrade ($129.99)",
        disabled: false,
        checked: false,
        labelPosition: "after"
      }, {
        name: "Software Installation ($49.99)",
        disabled: false,
        checked: false,
        labelPosition: "after"
      }, {
        name: "Tune-up ($89.99)",
        disabled: false,
        checked: false,
        labelPosition: "after"
      }, {
        name: "Keyboard Cleaning ($45.00)",
        disabled: false,
        checked: false,
        labelPosition: "after"
      }, {
        name: "Disk Clean-up ($149.99)",
        disabled: false,
        checked: false,
        labelPosition: "after"
      },
    ]

  }
/*
  master_change() {
    for (let value of Object.values(this.checkbox_list)) {
      value.checked = this.master_checked;
    }
  }
*/
  list_change(e){
    console.log('in list_change');
    for (let value of Object.values(this.checkbox_list)) {
      alert(value.name + e);
      /*
      if (!value.checked) {
      value.checked = true;
      console.log('in if on list_change');
     console.log(value.checked);
      }
      */
    }


    /*let checked_count = 0;
    //Get total checked items
    console.log('in list_change');
    console.log(Object.values(this.checkbox_list));
    for (let value of Object.values(this.checkbox_list)) {
      if(value.checked)
      checked_count++;
    }

    if(checked_count>0 && checked_count<this.checkbox_list.length){
      // If some checkboxes are checked but not all; then set Indeterminate state of the master to true.
      this.master_indeterminate = true;
    }else if(checked_count == this.checkbox_list.length){
      //If checked count is equal to total items; then check the master checkbox and also set Indeterminate state to false.
      this.master_indeterminate = false;
      this.master_checked = true;
    }else{
      //If none of the checkboxes in the list is checked then uncheck master also set Indeterminate to false.
      this.master_indeterminate = false;
      this.master_checked = false;
    }*/
  }

  ngOnInit(): void {

    this.servicesForm = this.fb.group({
      parts: [''],
      labor: ['']
    })
  }

  get form() { return this.servicesForm.controls; }
  /*
  onSubmit(event) {
    this.transcriptEntries.push({
      course: this.form.course.value,
      grade: this.form.grade.value
    });

    event.currentTarget.reset();
  }
*/
  calculateResults() {
    let invoice: number = 0;
    for (let value of Object.values(this.checkbox_list)) {
      console.log(value.checked);

      console.log(value.name)

      if(value.checked) {
        console.log('its checked');

   // for (let entry of this.services_selected_list) {
   //   console.log(entry.item.name)
   //   switch(entry.item.name) {
     //create an IService with descritpion and price.
     //push IService to IServiceArray
     //popup of Invoice

      switch(value.name) {
        case 'Password Reset ($39.99)':
          console.log('its an a')
          invoice += 39.99;
          this.services.push({
            description: value.name,
            cost: 39.99
          });
        case 'Spyware Removal ($99.99)':
          invoice += 99.99;
          this.services.push({
            description: value.name,
            cost: 99.99
          });
        case 'RAM Upgrade ($129.99)':
          invoice += 129.99;
          this.services.push({
            description: value.name,
            cost: 129.99
          });
        case 'Software Installation ($49.99)':
          invoice += 49.99;
          this.services.push({
            description: value.name,
            cost: 49.99
          });
        case 'Tune-up ($89.99)':
          invoice += 89.99;
          this.services.push({
            description: value.name,
            cost: 89.99
          });
        case 'Keyboard Cleaning ($45.00)':
          invoice += 45.00;
          this.services.push({
            description: value.name,
            cost: 45.00
          });
        case 'Disk Clean-up ($149.99)':
          invoice += 149.99;
          this.services.push({
            description: value.name,
            cost: 149.99
          });
        default:
          invoice += 0.00;
          break;
      }
    }
    }

    if (this.form.parts.value) {
      invoice += this.form.parts.value;
      this.services.push({
        description: 'Parts',
        cost: this.form.parts.value
      });
    }

    if (this.form.labor.value) {
      invoice += this.form.labor.value * 50;
      this.services.push({
        description: 'Labor',
        cost: this.form.labor.value * 50
      });
    }
   console.log(invoice);
   //console.log(this.services[0]);
   // this.invoiceTotal = invoice / this.transcriptEntries.length;
   this.invoiceTotal = invoice;
    console.log(this.invoiceTotal);
  }

  clearEntries() {
   // this.transcriptEntries = [];
    this.invoiceTotal = 0;
  }
}
