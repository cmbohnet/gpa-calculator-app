/**
 * Title: home.component.ts
 * Author: Chris Bohnet
 * Date: 11 August 2020
 * Description: home.component file
 */
import { Component, OnInit } from '@angular/core';
import { ITranscript } from '../transcript.interface';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  selectableServices: Array<string> = ['Password Reset ($39.99)', 'Spyware Removal ($99.99)', 'RAM Upgrade ($129.99)', 'Software Installation ($49.99)', 'Tune-up ($89.99)', 'Keyboard Cleaning ($45.00)', 'Disk Clean-up ($149.99)'];
  transcriptEntries: Array<ITranscript> = [];
  invoiceTotal: number = 0;;
  transcriptForm: FormGroup;



  constructor(private fb: FormBuilder) {

  }


  ngOnInit(): void {
    this.transcriptForm = this.fb.group({
      course: ['', Validators.required],
      grade: ['', Validators.required]
    })
  }

  get form() { return this.transcriptForm.controls; }

  onSubmit(event) {
    this.transcriptEntries.push({
      course: this.form.course.value,
      grade: this.form.grade.value
    });

    event.currentTarget.reset();
  }

  calculateResults() {
    let invoice: number = 0;

    for (let entry of this.transcriptEntries) {
      console.log(entry.grade)
      switch(entry.grade) {
        case 'Password Reset ($39.99)':
          console.log('its an a')
          invoice += 39.99;
          break;
        case 'Spyware Removal ($99.99)':
          invoice += 99.99;
          break;
        case 'RAM Upgrade ($129.99)':
          invoice += 129.99;
          break;
        case 'Software Installation ($49.99)':
          invoice += 49.99;
          break;
        case 'Tune-up ($89.99)':
          invoice += 89.99;
          break;
        case 'Keyboard Cleaning ($45.00)':
          invoice += 45.00;
          break;
        case 'Disk Clean-up ($149.99)':
          invoice += 149.99;
          break;
        default:
          invoice += 0.00;
          break;
      }
    }

   // console.log(invoice);
   // this.invoiceTotal = invoice / this.transcriptEntries.length;
   this.invoiceTotal = invoice;
    console.log(this.invoiceTotal);
  }

  clearEntries() {
    this.transcriptEntries = [];
    this.invoiceTotal = 0;
  }
}
